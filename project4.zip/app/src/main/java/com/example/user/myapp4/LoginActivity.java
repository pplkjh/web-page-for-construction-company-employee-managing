package com.example.user.myapp4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Date;


public class LoginActivity extends AppCompatActivity {
    public static final String EXTRA_USERNAME = "com.example.myfirstapp.USERNAME";
    public static final String EXTRA_PASSWORD = "com.example.myfirstapp.PASSWORD";
    public static final String EXTRA_DATE = "com.example.myfirstapp.DATE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText dateToSearch = (EditText) findViewById(R.id.editDate);
        String todaysDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        dateToSearch.setText(todaysDate);
    }

    /** Called when the user taps the Send button */
    public void sendMessage(View view) {
        EditText editUser = (EditText) findViewById(R.id.edit_username);
        String username = editUser.getText().toString();

        EditText editPass = (EditText) findViewById(R.id.edit_Passwd);
        String password = editPass.getText().toString();

        EditText dateToSearch = (EditText) findViewById(R.id.editDate);
        String todaysDate = dateToSearch.getText().toString();

        Intent intent = new Intent(this, ConfirmLoginActivity.class);
        intent.putExtra(EXTRA_USERNAME, username);
        intent.putExtra(EXTRA_PASSWORD, password);
        intent.putExtra(EXTRA_DATE, todaysDate);

        startActivity(intent);
    }
}